#include <stdio.h>


int main() {
	unsigned long long a = 10;
	printf("%d\n", sizeof(a));
	return 0;
}